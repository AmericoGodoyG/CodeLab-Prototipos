﻿using MongoDB.Driver;
using Microsoft.Extensions.Configuration;

public class MongoDBService
{
    private readonly IMongoCollection<Questao> _questoes;

    public MongoDBService(IConfiguration config)
    {
        var client = new MongoClient(config.GetValue<string>("MongoDB:ConnectionString"));
        var database = client.GetDatabase(config.GetValue<string>("MongoDB:DatabaseName"));
        _questoes = database.GetCollection<Questao>(config.GetValue<string>("MongoDB:CollectionName"));
    }

    public async Task<List<Questao>> GetQuestoesAsync()
    {
        return await _questoes.Find(q => true).ToListAsync();
    }

    public async Task<Questao> GetQuestaoByIdAsync(string id)
    {
        return await _questoes.Find(q => q.Id == id).FirstOrDefaultAsync();
    }

    public async Task CreateQuestaoAsync(Questao questao)
    {
        await _questoes.InsertOneAsync(questao);
    }

    public async Task DeleteQuestaoAsync(string id)
    {
        await _questoes.DeleteOneAsync(q => q.Id == id);
    }
}
