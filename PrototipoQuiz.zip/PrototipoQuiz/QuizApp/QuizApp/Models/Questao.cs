﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

public class Questao
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string Id { get; set; }

    [BsonElement("pergunta")]
    public string Pergunta { get; set; }

    [BsonElement("opcoes")]
    public string[] Opcoes { get; set; }

    [BsonElement("respostaCorreta")]
    public string RespostaCorreta { get; set; }

    [BsonElement("linguagem")]
    public string Linguagem { get; set; }
}
