﻿using Microsoft.AspNetCore.Mvc;

public class QuizController : Controller
{
    private readonly MongoDBService _mongoDBService;

    public QuizController(MongoDBService mongoDBService)
    {
        _mongoDBService = mongoDBService;
    }

    // Ação para listar as questões
    public async Task<IActionResult> Index()
    {
        var questoes = await _mongoDBService.GetQuestoesAsync();
        return View(questoes);
    }

    // Ação para exibir o formulário de criação de nova questão
    public IActionResult NovaQuestao()
    {
        return View();
    }

    // Ação para processar o envio do formulário de criação
    [HttpPost]
    public async Task<IActionResult> NovaQuestao(Questao questao)
    {
        if (ModelState.IsValid)
        {
            await _mongoDBService.CreateQuestaoAsync(questao);
            return RedirectToAction("Index");
        }
        return View(questao);
    }

    // Ação para deletar uma questão
    public async Task<IActionResult> Delete(string id)
    {
        await _mongoDBService.DeleteQuestaoAsync(id);
        return RedirectToAction("Index");
    }
}

